
	<div class="footerMain">
		<div class="content">
			<div class="footer-grids">
				<div class="footer one">
					<h3>Birat Kshitiz College</h3>
					<p>PHP Project</p>
					<p class="adam">- Kaushal, Sulabh, Sushil</p>
					<div class="clear"></div>
				</div>
				<div class="footer two">
					<h3>Keep Connected</h3>
					<ul>
						<li><a class="fb" href="https://www.facebook.com"><i></i>Stay connected with educational hub</a></li>
						<li><a class="fb1" href="https://www.youtube.com"><i></i>Follow us for tutor</a></li>
					</ul>
				</div>
				<div class="footer three">
					<h3>Contact Information</h3>
					<ul>
						<li>9823445986</li>
						<li><a href="educationhub@example.com">educationhub@example.com</a></li>
					</ul>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>